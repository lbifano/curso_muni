Config={};
Config.gps_activado = false;
Config.cant_fotos = 2;
Config.test = false;
Config.width_fotos = 200;
Config.server = 'http://192.168.0.128/laplata_ws/index.php/';
Config.token_test = '635136ec0a33464c1f837d32e8110121524f30efeffa770db9b82e1c1487f8f140ede4387de890e44c28d1fd47624a8a86b0fe55b9fd0ba4e38a2977ed60ace70499bf6419b9f145c650fa45b2b681416adfc223b700993bf720a880a5ade7ccad7ba69ed10323e17a187615771e9eb53e431dd53cb4921db06f82a631bd7b39';
